class Config:
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://shchala:1234@localhost/flask_project_home_work_lecture_36_db"
    SQLALCHEMY_ECHO = True