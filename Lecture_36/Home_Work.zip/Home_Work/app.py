from flask import Flask, request, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

db = SQLAlchemy(app)

migrate = Migrate(app, db)


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(50), unique=True, nullable=False)
    author = db.Column(db.String(50), nullable=False)
    year = db.Column(db.Integer, nullable=False)


@app.route("/")
def main_page():
    return "<h1>Main page...</h1>"


@app.route("/home", methods=['POST', 'GET'])
def home():
    if request.method == 'POST':
        return "<h1>Post page...</h1>"
    elif request.method == 'GET':
        return "<h1>Get page...</h1>"


@app.route("/create_book", methods=['POST', 'GET'])
def create_book():
    if request.method == "POST":
        title = request.form['title']
        author = request.form['author']
        year = request.form['year']

        book = Book(title=title, author=author, year=year)

        db.session.add(book)
        db.session.commit()

        return "Book created successfully..."

    elif request.method == "GET":
        return render_template("create_book.html")


@app.route("/update_book/<int:book_id>", methods=['POST', 'GET'])
def update_book(book_id):
    book = Book.query.get_or_404(book_id)
    if request.method == "POST":
        title = request.form['title']
        author = request.form['author']
        year = request.form['year']

        book.title = title
        book.author = author
        book.year = year

        db.session.commit()

        return "Book updated successfully..."
    elif request.method == "GET":
        return render_template("update_book.html", book=book)
    

@app.route("/book/<int:book_id>")
def get_book(book_id):
    book = Book.query.get_or_404(book_id)

    return f"<p>Title: {book.title}, Author: {book.author}, Year: {book.year}</p>"


@app.route("/books")
def books():
    books = Book.query.all()

    res = ""

    for book in books:
        res += f"<p>Title: {book.title}, Author: {book.author}, Year: {book.year}</p>"

    return res


@app.route("/delete_book/<int:book_id>")
def delete_book(book_id):
    book = Book.query.get_or_404(book_id)
    db.session.delete(book)
    db.session.commit()

    return f"<p>Book with ID {book_id} deleted successfully.</p>"


# ========================
if __name__ == '__main__':
    app.run(debug=True)